#' Functions for exploring the contents of a data frame.
#'
#' edatools provides tools for exploring the variables in
#' a data frame.
#'
#' @docType package
#' @name edatools-package
#' @aliases edatools
NULL
